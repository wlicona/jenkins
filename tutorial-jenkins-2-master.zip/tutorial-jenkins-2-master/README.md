# Tutorial Jenkins 2 – Configuración pipeline


## Información
Este repositorio incluye la aplicación de ejemplo y la configuración el pipeline de Jenkis utilizado en el tutorial [Tutorial Jenkins 2 – Configuración pipeline](http://dmunozfer.es/tutorial-jenkins-2-configuracion-pipeline)

## Contenido del tutorial

En este tutorial aprenderemos los fundamentos de los pipelines de Jenkins y configuraremos uno sencillo en el que integraremos una aplicación **java con spring boot + maven + github**. El pipeline lo mantendremos en el propio repositorio de github y conectaremos Github con Jenkins mediante **hooks** de forma que cada vez que se realice un commit en el repositorio se ejecute de forma automática el pipeline de Jenkins.